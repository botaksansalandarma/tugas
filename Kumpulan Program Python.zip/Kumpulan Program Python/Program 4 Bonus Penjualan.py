gaji = 5000000
produk = int(input("Produk yang terjual : "))
harga_satuan = int(input("Harga satuan produk : "))

if produk > 100:
    bonus = 0.2*(produk*harga_satuan)
else:
    bonus = 0.1*(produk*harga_satuan)

total = gaji+bonus

print ("Gaji salesman tersebut adalah Rp.", total)