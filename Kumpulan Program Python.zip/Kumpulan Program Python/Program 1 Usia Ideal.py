usia = int(input("Berapa usia anda?\nJawab : "))

if usia < 25:
    if usia < 20:
        print ("Idealnya anda masih sekolah")
    if usia >= 20:
        print ("Idealnya anda sudah bekerja")

elif usia > 25:
    if usia < 30:
        print ("Idealnya anda sudah menikah")
    if usia >= 30:
        print ("Idealnya anda sudah memiliki anak")
else:
    print ("Maaf, mungkin jawaban anda salah")   