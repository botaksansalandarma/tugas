print ("=======================================================")
print ("17230585_Rianto Surya Pratama_17.1A.11_Tugas Kelompok 5 (3)")
print ("=======================================================")

n = 6
for i in range(1, n+1):
    for j in range(n, i, -1):
        print(end=" ")
    for k in range(1, i+1):
        print("* ", end="")
    print()
print()
print("baris =", n)