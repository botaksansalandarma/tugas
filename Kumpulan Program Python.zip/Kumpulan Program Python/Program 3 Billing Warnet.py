beli = int(input("Masukkan lama pemakaian (jam) : "))

if beli <= 3:
    bayar = 6000 * beli
else:
    bayar = 6000 * 3 + (beli - 3) * 5000
print ("Biaya Penyewaan Warnet : ", bayar)