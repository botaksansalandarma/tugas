print("=============== TOKO MAINAN ANAK ===============")
print("------------------------------------------------")
nama = input("Masukkan Nama Pembeli : ")
kode = input("Masukkan Kode Mainan : ")
harga = int(input("Masukkan Harga : "))
jumlah = int(input("Masukkan Harga : "))
total = jumlah * harga

print("================================================")
print("Nama Pembeli = " +str(nama))
print("Kode Mainan  = " +str(kode))
print("Harga        = " +str (harga))
print("Jumlah beli  = " +str(jumlah))
print("Total        = " +str(total))