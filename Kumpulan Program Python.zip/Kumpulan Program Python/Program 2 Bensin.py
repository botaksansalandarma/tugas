total = int(input("Jumlah bensin yang dibeli (Rp.) : "))
bonus1 = 1,5
bonus2 = 1
bonus3 = 0,5

if total > 100000:
    print("Selamat, anda mendapatkan bonus bensin sebanyak", bonus1, "liter")
elif total >= 90000:
    print("Selamat, anda mendapatkan bonus bensin sebanyak", bonus2, "liter")
elif total >= 80000:
    print("Selamat, anda mendapatkan bonus bensin sebanyak", bonus3, "liter")
else:
    print("Tidak ada bonus dalam pembelian ini")